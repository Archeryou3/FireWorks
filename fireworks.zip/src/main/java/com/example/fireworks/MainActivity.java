package com.example.fireworks;
import android.os.Handler;
import android.os.Looper;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.kaisengao.likeview.like.KsgLikeView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private KsgLikeView mLikeView;

    private Button mMore;
    static  int i=0;


    Handler mhandler=new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView() {

        mLikeView = findViewById(R.id.live_view);
        findViewById(R.id.live_view_single).setOnClickListener(this);
        mMore=findViewById(R.id.live_view_more);
        mMore .setOnClickListener(this);

        mLikeView.addLikeImage(R.drawable.heart0);
        mLikeView.addLikeImage(R.drawable.heart1);
        mLikeView.addLikeImage(R.drawable.heart2);
        mLikeView.addLikeImage(R.drawable.heart3);
        mLikeView.addLikeImage(R.drawable.heart4);
        mLikeView.addLikeImage(R.drawable.heart5);
        mLikeView.addLikeImage(R.drawable.heart6);
        mLikeView.addLikeImage(R.drawable.heart7);
        mLikeView.addLikeImage(R.drawable.heart8);
    }

//选择点赞方式
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.live_view_single:
                mLikeView.addFavor();
                break;
            case R.id.live_view_more:
                i=0;
                boolean selected = mMore.isSelected();
                if (selected){
                    mhandler.removeCallbacks(runnable);
                }else {
                    mhandler.postDelayed(runnable,100);
                }
                mMore.setSelected(!selected);
                break;

            default:
                break;
        }
    }
//通过设置i的数量控制爱心个数，我这里设置的是20个。
    private Runnable runnable=new Runnable() {
        @Override
        public void run() {
            if(i<20) {
                mLikeView.addFavor();
                i++;
            }
            Log.i("MainActivity.class","ieo="+i);
            mhandler.postDelayed(runnable,100);
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mhandler.removeCallbacks(runnable);
    }
}

